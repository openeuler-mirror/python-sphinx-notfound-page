"""
Sample ``conf.py``.
"""

master_doc = 'index'

extensions = [
    'notfound.extension',
]


