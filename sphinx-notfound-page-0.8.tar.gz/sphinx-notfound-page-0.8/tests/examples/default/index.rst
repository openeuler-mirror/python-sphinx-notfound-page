Example page
============

This is an example page.


.. toctree::
   :glob:

   *
