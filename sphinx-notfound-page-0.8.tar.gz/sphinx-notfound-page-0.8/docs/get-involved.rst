Get Involved
============

We appreciate a lot your interest on getting involved in this small project!
Your help will benefit a lot of people around the world.

Please, if you want to collaborate with us,
you can check out `the list of issues we have on GitHub`_ and comment there if you need further guidance or just send a Pull Request |:heart:|.

.. _the list of issues we have on GitHub: https://github.com/readthedocs/sphinx-notfound-page/issues?q=is%3Aissue+is%3Aopen+sort%3Aupdated-desc
